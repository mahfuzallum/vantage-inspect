import "server-only";
import { unstable_cache, revalidateTag } from "next/cache";
import { db } from "@/lib/db";
import { siteConfig } from "@/config/site";

export type SettingsGroup = "general" | "seo" | "features" | "home" | "security";

/**
 * Defaults for the home page.
 *
 * These were literals inside the hero and the page. Keeping them here means a
 * fresh install still renders sensible copy, while an administrator can change
 * any of it without touching a component.
 */
export const HOME_DEFAULTS = {
  heroTitle: "Explore a New Largest Webcam Video Archive",
  heroDescription:
    "Explore an organized collection of videos from creators, streamers, webcams and platforms across the web, all in one searchable archive.",
  quickLinks: "Webcam, OnlyFans, Couples, Popular, New Releases",
  featuredOrder: [] as string[],
};

/** Falls back to build-time config so a fresh install renders correctly. */
export const getSettings = unstable_cache(
  async (group: SettingsGroup): Promise<Record<string, unknown>> => {
    const rows = await db.siteSetting.findMany({ where: { group } });
    const values = Object.fromEntries(rows.map((row) => [row.key, row.value]));

    if (group === "general") {
      return { siteName: siteConfig.name, tagline: siteConfig.tagline, ...values };
    }
    if (group === "seo") {
      return {
        defaultTitle: siteConfig.name,
        defaultDescription: siteConfig.description,
        defaultOgImage: siteConfig.defaultOgImage,
        ...values,
      };
    }
    if (group === "home") {
      return { ...HOME_DEFAULTS, ...values };
    }
    return values;
  },
  ["site-settings"],
  { revalidate: 300, tags: ["settings"] },
);

export async function upsertSetting(
  key: string,
  value: unknown,
  group: SettingsGroup,
): Promise<void> {
  await db.siteSetting.upsert({
    where: { key },
    create: { key, group, value: value as never },
    update: { value: value as never, group },
  });
  revalidateTag("settings");
}
