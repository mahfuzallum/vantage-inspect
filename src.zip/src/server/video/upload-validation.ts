import "server-only";
import { serverEnv } from "@/lib/env";

/**
 * Upload gatekeeping.
 *
 * The extension is treated as a hint and nothing more — the decision is made
 * from the file's own magic bytes, and then confirmed a third time by ffprobe
 * in the worker. A file called `clip.mp4` that is really a shell script fails
 * every one of those checks.
 */

export const ALLOWED_VIDEO_EXTENSIONS = ["mp4", "mov", "webm", "mkv", "m4v"] as const;

export const ALLOWED_VIDEO_MIME_TYPES = [
  "video/mp4",
  "video/quicktime",
  "video/webm",
  "video/x-matroska",
  "video/x-m4v",
] as const;

/** Extensions that must never be accepted, whatever the client claims. */
const DANGEROUS_EXTENSIONS = new Set([
  "exe", "dll", "so", "dylib", "bat", "cmd", "com", "scr", "msi", "app",
  "sh", "bash", "zsh", "ps1", "php", "phtml", "jsp", "asp", "aspx",
  "js", "mjs", "cjs", "py", "rb", "pl", "jar", "war", "svg", "html", "htm",
]);

export type UploadRejection = { ok: false; reason: string };
export type UploadAcceptance = { ok: true; extension: string; detectedMime: string };
export type UploadCheck = UploadRejection | UploadAcceptance;

/**
 * Container signatures, checked against the head of the file.
 * MP4/MOV carry an `ftyp` box at offset 4; WebM and MKV share the EBML magic.
 */
function sniffContainer(head: Buffer): string | null {
  if (head.length < 12) return null;

  if (head.subarray(4, 8).toString("ascii") === "ftyp") {
    const brand = head.subarray(8, 12).toString("ascii");
    if (brand.startsWith("qt")) return "video/quicktime";
    return "video/mp4";
  }

  // EBML header — WebM and Matroska are the same container family.
  if (head[0] === 0x1a && head[1] === 0x45 && head[2] === 0xdf && head[3] === 0xa3) {
    const window = head.subarray(0, 64).toString("binary");
    return window.includes("webm") ? "video/webm" : "video/x-matroska";
  }

  return null;
}

export function maxUploadBytes(): number {
  return serverEnv().MAX_VIDEO_UPLOAD_MB * 1024 * 1024;
}

/**
 * Validates a candidate upload. `head` need only be the first few kilobytes.
 * Messages are written for an administrator to act on.
 */
export function validateUpload(params: {
  filename: string;
  sizeBytes: number;
  declaredMime: string;
  head: Buffer;
}): UploadCheck {
  const { filename, sizeBytes, declaredMime, head } = params;

  const extension = (filename.split(".").pop() ?? "").toLowerCase().replace(/[^a-z0-9]/g, "");

  if (!extension) {
    return { ok: false, reason: "The file has no extension." };
  }
  if (DANGEROUS_EXTENSIONS.has(extension)) {
    return { ok: false, reason: "Executable and script files cannot be uploaded." };
  }
  if (!(ALLOWED_VIDEO_EXTENSIONS as readonly string[]).includes(extension)) {
    return {
      ok: false,
      reason: `Unsupported file type. Accepted: ${ALLOWED_VIDEO_EXTENSIONS.join(", ")}.`,
    };
  }

  if (sizeBytes <= 0) {
    return { ok: false, reason: "The file is empty." };
  }

  const limit = maxUploadBytes();
  if (sizeBytes > limit) {
    return {
      ok: false,
      reason: `The file is ${(sizeBytes / 1048576).toFixed(0)}MB. The limit is ${serverEnv().MAX_VIDEO_UPLOAD_MB}MB.`,
    };
  }

  if (!(ALLOWED_VIDEO_MIME_TYPES as readonly string[]).includes(declaredMime)) {
    return { ok: false, reason: `Unsupported media type: ${declaredMime}.` };
  }

  // The decisive check: what the bytes actually are.
  const detectedMime = sniffContainer(head);
  if (!detectedMime) {
    return {
      ok: false,
      reason: "The file contents are not a recognised video container.",
    };
  }

  return { ok: true, extension, detectedMime };
}
