"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { requireStaff, requireAdmin } from "@/lib/auth/guards";
import { AUDIT_ACTIONS, recordAudit } from "@/server/services/audit-service";
import { adminContentSchema, bulkContentSchema } from "@/validation/admin";
import { slugify, uniqueSlug } from "@/lib/utils/slug";
import { cuidSchema } from "@/validation/common";
import { routes } from "@/config/routes";

/**
 * Content mutations.
 *
 * Every action resolves the acting administrator from the session before doing
 * anything else, so a crafted request from a normal reader is rejected no
 * matter what it contains. Payloads are parsed through an explicit schema,
 * which drops any field the form has no business setting — view counts and
 * favourite counts cannot be written from here.
 */

import type { AdminFormState } from "./admin-form-state";
export type { AdminFormState } from "./admin-form-state";

function fieldErrorsFrom(error: { issues: Array<{ path: PropertyKey[]; message: string }> }) {
  const output: Record<string, string[]> = {};
  for (const issue of error.issues) {
    const key = String(issue.path[0] ?? "_");
    (output[key] ??= []).push(issue.message);
  }
  return output;
}

/** Reads the shared content form into a plain object. */
function readContentForm(formData: FormData) {
  return {
    title: formData.get("title"),
    slug: formData.get("slug") || undefined,
    summary: formData.get("summary") ?? undefined,
    description: formData.get("description") ?? undefined,
    kind: formData.get("kind") ?? "VIDEO",
    status: formData.get("status") ?? "DRAFT",
    isFeatured: formData.get("isFeatured") === "on",
    durationSeconds: formData.get("durationSeconds") || undefined,
    language: formData.get("language") ?? undefined,
    creatorId: formData.get("creatorId") ?? undefined,
    categoryId: formData.get("categoryId") ?? undefined,
    tagIds: formData.getAll("tagIds").map(String).filter(Boolean),
    thumbnailUrl: formData.get("thumbnailUrl") ?? undefined,
    externalUrl: formData.get("externalUrl") ?? undefined,
    seoTitle: formData.get("seoTitle") ?? undefined,
    seoDescription: formData.get("seoDescription") ?? undefined,
    ogImageUrl: formData.get("ogImageUrl") ?? undefined,
  };
}

/** Attaches an external image as a media asset without an upload pipeline. */
async function externalAsset(url: string | undefined, kind: "IMAGE" | "VIDEO", actorId: string) {
  if (!url) return null;
  const asset = await db.mediaAsset.create({
    data: { kind, provider: "EXTERNAL", url, uploadedById: actorId },
    select: { id: true },
  });
  return asset.id;
}

export async function createContentAction(
  _previous: AdminFormState,
  formData: FormData,
): Promise<AdminFormState> {
  const admin = await requireStaff();
  const parsed = adminContentSchema.safeParse(readContentForm(formData));
  if (!parsed.success) return { status: "error", fieldErrors: fieldErrorsFrom(parsed.error) };

  const data = parsed.data;
  let contentId: string;

  try {
    const slug = await uniqueSlug(data.slug ?? slugify(data.title), async (candidate) =>
      Boolean(await db.content.findUnique({ where: { slug: candidate }, select: { id: true } })),
    );

    const thumbnailId = await externalAsset(data.thumbnailUrl, "IMAGE", admin.id);

    // One transaction: the row and its tag links succeed together or not at all.
    const created = await db.$transaction(async (tx) => {
      const content = await tx.content.create({
        data: {
          slug,
          title: data.title,
          summary: data.summary ?? null,
          description: data.description ?? null,
          kind: data.kind,
          status: data.status,
          isFeatured: data.isFeatured,
          durationSeconds: data.durationSeconds ?? null,
          language: data.language ?? null,
          creatorId: data.creatorId ?? null,
          categoryId: data.categoryId ?? null,
          thumbnailId,
          externalUrl: data.externalUrl ?? null,
          seoTitle: data.seoTitle ?? null,
          seoDescription: data.seoDescription ?? null,
          ogImageUrl: data.ogImageUrl ?? null,
          publishedAt: data.status === "PUBLISHED" ? new Date() : null,
        },
        select: { id: true },
      });

      if (data.tagIds.length > 0) {
        await tx.contentTag.createMany({
          data: data.tagIds.map((tagId) => ({ contentId: content.id, tagId })),
          skipDuplicates: true,
        });
      }
      return content;
    });

    contentId = created.id;
    await recordAudit({
      actorId: admin.id,
      action: AUDIT_ACTIONS.CONTENT_CREATED,
      entityType: "content",
      entityId: contentId,
      metadata: { title: data.title, status: data.status },
    });
  } catch (error) {
    console.error("[admin] content create failed:", error);
    return { status: "error", message: "That didn't save. Try again." };
  }

  revalidatePath(routes.admin.content);
  redirect(routes.admin.contentEdit(contentId));
}

export async function updateContentAction(
  contentId: string,
  _previous: AdminFormState,
  formData: FormData,
): Promise<AdminFormState> {
  const admin = await requireStaff();

  const id = cuidSchema.safeParse(contentId);
  if (!id.success) return { status: "error", message: "Unknown record." };

  const parsed = adminContentSchema.safeParse(readContentForm(formData));
  if (!parsed.success) return { status: "error", fieldErrors: fieldErrorsFrom(parsed.error) };

  const data = parsed.data;

  try {
    const existing = await db.content.findUnique({
      where: { id: id.data },
      select: { id: true, slug: true, status: true, publishedAt: true, thumbnailId: true },
    });
    if (!existing) return { status: "error", message: "That record no longer exists." };

    // Only re-derive the slug when the administrator actually changed it.
    let slug = existing.slug;
    if (data.slug && data.slug !== existing.slug) {
      slug = await uniqueSlug(data.slug, async (candidate) =>
        Boolean(
          await db.content.findFirst({
            where: { slug: candidate, id: { not: id.data } },
            select: { id: true },
          }),
        ),
      );
    }

    const thumbnailId = data.thumbnailUrl
      ? ((await externalAsset(data.thumbnailUrl, "IMAGE", admin.id)) ?? existing.thumbnailId)
      : existing.thumbnailId;

    await db.$transaction(async (tx) => {
      await tx.content.update({
        where: { id: id.data },
        data: {
          slug,
          title: data.title,
          summary: data.summary ?? null,
          description: data.description ?? null,
          kind: data.kind,
          status: data.status,
          isFeatured: data.isFeatured,
          durationSeconds: data.durationSeconds ?? null,
          language: data.language ?? null,
          creatorId: data.creatorId ?? null,
          categoryId: data.categoryId ?? null,
          thumbnailId,
          externalUrl: data.externalUrl ?? null,
          seoTitle: data.seoTitle ?? null,
          seoDescription: data.seoDescription ?? null,
          ogImageUrl: data.ogImageUrl ?? null,
          // Stamp the first publication only; re-saving must not move the date.
          publishedAt:
            data.status === "PUBLISHED"
              ? (existing.publishedAt ?? new Date())
              : existing.publishedAt,
        },
      });

      // Tag links are replaced wholesale inside the transaction.
      await tx.contentTag.deleteMany({ where: { contentId: id.data } });
      if (data.tagIds.length > 0) {
        await tx.contentTag.createMany({
          data: data.tagIds.map((tagId) => ({ contentId: id.data, tagId })),
          skipDuplicates: true,
        });
      }
    });

    await recordAudit({
      actorId: admin.id,
      action: AUDIT_ACTIONS.CONTENT_UPDATED,
      entityType: "content",
      entityId: id.data,
      metadata: { title: data.title, status: data.status },
    });
  } catch (error) {
    console.error("[admin] content update failed:", error);
    return { status: "error", message: "That didn't save. Try again." };
  }

  revalidatePath(routes.admin.content);
  revalidatePath(routes.content(data.slug ?? ""));
  return { status: "success", message: "Saved." };
}

/** Single-record status change, used by the row actions. */
export async function setContentStatusAction(
  contentId: string,
  status: "DRAFT" | "PUBLISHED" | "ARCHIVED",
): Promise<void> {
  const admin = await requireStaff();
  const id = cuidSchema.safeParse(contentId);
  if (!id.success) return;

  const existing = await db.content.findUnique({
    where: { id: id.data },
    select: { publishedAt: true },
  });
  if (!existing) return;

  await db.content.update({
    where: { id: id.data },
    data: {
      status,
      publishedAt:
        status === "PUBLISHED" ? (existing.publishedAt ?? new Date()) : existing.publishedAt,
    },
  });

  await recordAudit({
    actorId: admin.id,
    action:
      status === "PUBLISHED"
        ? AUDIT_ACTIONS.CONTENT_PUBLISHED
        : status === "ARCHIVED"
          ? AUDIT_ACTIONS.CONTENT_ARCHIVED
          : AUDIT_ACTIONS.CONTENT_UNPUBLISHED,
    entityType: "content",
    entityId: id.data,
  });

  revalidatePath(routes.admin.content);
}

export async function toggleFeaturedAction(contentId: string): Promise<void> {
  const admin = await requireStaff();
  const id = cuidSchema.safeParse(contentId);
  if (!id.success) return;

  const existing = await db.content.findUnique({
    where: { id: id.data },
    select: { isFeatured: true },
  });
  if (!existing) return;

  await db.content.update({
    where: { id: id.data },
    data: { isFeatured: !existing.isFeatured },
  });

  await recordAudit({
    actorId: admin.id,
    action: AUDIT_ACTIONS.CONTENT_FEATURED,
    entityType: "content",
    entityId: id.data,
    metadata: { featured: !existing.isFeatured },
  });

  revalidatePath(routes.admin.content);
}

/** Deleting content is ADMIN-only; moderators can archive instead. */
export async function deleteContentAction(contentId: string): Promise<void> {
  const admin = await requireAdmin();
  const id = cuidSchema.safeParse(contentId);
  if (!id.success) return;

  const existing = await db.content.findUnique({
    where: { id: id.data },
    select: { title: true },
  });
  if (!existing) return;

  // Tag links, favourites, views and history cascade from Content.
  await db.content.delete({ where: { id: id.data } });

  await recordAudit({
    actorId: admin.id,
    action: AUDIT_ACTIONS.CONTENT_DELETED,
    entityType: "content",
    entityId: id.data,
    metadata: { title: existing.title },
  });

  revalidatePath(routes.admin.content);
}

/**
 * Bulk operations.
 *
 * Deletion additionally requires an explicit confirmation flag and the ADMIN
 * role, so a mis-click on a checkbox column cannot destroy a page of records.
 */
export async function bulkContentAction(
  _previous: AdminFormState,
  formData: FormData,
): Promise<AdminFormState> {
  const admin = await requireStaff();

  const parsed = bulkContentSchema.safeParse({
    ids: formData.getAll("ids").map(String),
    action: formData.get("action"),
    confirmed: formData.get("confirmed") === "true",
  });
  if (!parsed.success) {
    return { status: "error", message: parsed.error.issues[0]?.message ?? "Select items first." };
  }

  const { ids, action, confirmed } = parsed.data;

  try {
    if (action === "delete") {
      if (admin.role !== "ADMIN") {
        return { status: "error", message: "Only an administrator can delete records." };
      }
      if (!confirmed) {
        return { status: "error", message: "Confirm the deletion before continuing." };
      }
      await db.content.deleteMany({ where: { id: { in: ids } } });
      await recordAudit({
        actorId: admin.id,
        action: AUDIT_ACTIONS.CONTENT_DELETED,
        entityType: "content",
        metadata: { bulk: true, count: ids.length },
      });
      revalidatePath(routes.admin.content);
      return { status: "success", message: `Deleted ${ids.length} record(s).` };
    }

    const data =
      action === "publish"
        ? { status: "PUBLISHED" as const, publishedAt: new Date() }
        : action === "unpublish"
          ? { status: "DRAFT" as const }
          : action === "archive"
            ? { status: "ARCHIVED" as const }
            : { isFeatured: action === "feature" };

    await db.content.updateMany({ where: { id: { in: ids } }, data });

    await recordAudit({
      actorId: admin.id,
      action: AUDIT_ACTIONS.CONTENT_UPDATED,
      entityType: "content",
      metadata: { bulk: true, action, count: ids.length },
    });

    revalidatePath(routes.admin.content);
    return { status: "success", message: `Updated ${ids.length} record(s).` };
  } catch (error) {
    console.error("[admin] bulk action failed:", error);
    return { status: "error", message: "That didn't complete. Try again." };
  }
}
