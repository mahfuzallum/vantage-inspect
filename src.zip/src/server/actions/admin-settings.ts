"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/auth/guards";
import { upsertSetting } from "@/server/services/settings-service";
import { AUDIT_ACTIONS, recordAudit } from "@/server/services/audit-service";
import {
  homeSettingsSchema,
  seoSettingsSchema,
  siteSettingsSchema,
  unlockCodeSchema,
} from "@/validation/admin";
import { hashPassword, verifyPassword } from "@/lib/auth/password";
import { routes } from "@/config/routes";
import type { AdminFormState } from "./admin-content";

/**
 * Site and SEO configuration.
 *
 * Values are stored per key in `site_settings` and read through the cached
 * settings service, so nothing here is hardcoded into a component. Both
 * actions are ADMIN-only and audited — configuration changes are exactly the
 * kind of thing that needs a trail afterwards.
 */

function fieldErrorsFrom(error: { issues: Array<{ path: PropertyKey[]; message: string }> }) {
  const output: Record<string, string[]> = {};
  for (const issue of error.issues) {
    const key = String(issue.path[0] ?? "_");
    (output[key] ??= []).push(issue.message);
  }
  return output;
}

export async function updateSiteSettingsAction(
  _previous: AdminFormState,
  formData: FormData,
): Promise<AdminFormState> {
  const admin = await requireAdmin();

  const parsed = siteSettingsSchema.safeParse({
    siteName: formData.get("siteName"),
    tagline: formData.get("tagline") ?? undefined,
    contactEmail: formData.get("contactEmail") ?? undefined,
    paginationSize: formData.get("paginationSize") ?? 24,
    maintenanceMode: formData.get("maintenanceMode") === "on",
    maintenanceMessage: formData.get("maintenanceMessage") ?? undefined,
  });
  if (!parsed.success) return { status: "error", fieldErrors: fieldErrorsFrom(parsed.error) };

  try {
    for (const [key, value] of Object.entries(parsed.data)) {
      await upsertSetting(key, value ?? null, "general");
    }

    await recordAudit({
      actorId: admin.id,
      action: AUDIT_ACTIONS.SETTINGS_CHANGED,
      entityType: "settings",
      entityId: "general",
      // Keys only — a settings diff must not become a place secrets leak into.
      metadata: { keys: Object.keys(parsed.data) },
    });
  } catch (error) {
    console.error("[admin] settings update failed:", error);
    return { status: "error", message: "That didn't save. Try again." };
  }

  revalidatePath(routes.admin.settings);
  return { status: "success", message: "Settings saved." };
}

export async function updateSeoSettingsAction(
  _previous: AdminFormState,
  formData: FormData,
): Promise<AdminFormState> {
  const admin = await requireAdmin();

  const parsed = seoSettingsSchema.safeParse({
    defaultTitle: formData.get("defaultTitle"),
    defaultDescription: formData.get("defaultDescription"),
    defaultOgImage: formData.get("defaultOgImage") ?? undefined,
    twitterHandle: formData.get("twitterHandle") ?? undefined,
    robotsAllowIndexing: formData.get("robotsAllowIndexing") === "on",
  });
  if (!parsed.success) return { status: "error", fieldErrors: fieldErrorsFrom(parsed.error) };

  try {
    for (const [key, value] of Object.entries(parsed.data)) {
      await upsertSetting(key, value ?? null, "seo");
    }

    await recordAudit({
      actorId: admin.id,
      action: AUDIT_ACTIONS.SETTINGS_CHANGED,
      entityType: "settings",
      entityId: "seo",
      metadata: { keys: Object.keys(parsed.data) },
    });
  } catch (error) {
    console.error("[admin] SEO settings update failed:", error);
    return { status: "error", message: "That didn't save. Try again." };
  }

  revalidatePath(routes.admin.seo);
  return { status: "success", message: "SEO defaults saved." };
}

/**
 * Home page copy and the featured lineup.
 *
 * The order of `featuredOrder` is the order on the page — first id takes the
 * large slot. Ids are stored rather than a flag on each record, because the
 * position of an item is a property of the page, not of the recording, and a
 * recording can be featured without being first.
 */
export async function updateHomeSettingsAction(
  _previous: AdminFormState,
  formData: FormData,
): Promise<AdminFormState> {
  const admin = await requireAdmin();

  const parsed = homeSettingsSchema.safeParse({
    heroTitle: formData.get("heroTitle"),
    heroDescription: formData.get("heroDescription") ?? undefined,
    quickLinks: formData.get("quickLinks") ?? undefined,
    featuredOrder: formData.getAll("featuredOrder").map(String).filter(Boolean),
  });
  if (!parsed.success) return { status: "error", fieldErrors: fieldErrorsFrom(parsed.error) };

  try {
    for (const [key, value] of Object.entries(parsed.data)) {
      await upsertSetting(key, value ?? null, "home");
    }

    await recordAudit({
      actorId: admin.id,
      action: AUDIT_ACTIONS.SETTINGS_CHANGED,
      entityType: "settings",
      entityId: "home",
      metadata: { keys: Object.keys(parsed.data), featured: parsed.data.featuredOrder.length },
    });
  } catch (error) {
    console.error("[admin] home settings update failed:", error);
    return { status: "error", message: "That didn't save. Try again." };
  }

  revalidatePath(routes.home);
  revalidatePath(routes.admin.home);
  return { status: "success", message: "Home page updated." };
}

/**
 * Changes the administrator unlock code.
 *
 * The current code is required even though the caller is already an
 * authenticated administrator: it stops a borrowed session — an unlocked
 * laptop, a shared machine — from quietly replacing the code and locking the
 * owner out. Stored hashed, never in plaintext.
 *
 * The exception is the first change, when no code has been set at all: there
 * is nothing to confirm against, so the field is skipped.
 */
export async function updateUnlockCodeAction(
  _previous: AdminFormState,
  formData: FormData,
): Promise<AdminFormState> {
  const admin = await requireAdmin();

  const parsed = unlockCodeSchema.safeParse({
    currentCode: formData.get("currentCode") ?? undefined,
    newCode: formData.get("newCode"),
    confirmCode: formData.get("confirmCode"),
  });
  if (!parsed.success) return { status: "error", fieldErrors: fieldErrorsFrom(parsed.error) };

  try {
    const existing = await db.siteSetting.findUnique({
      where: { key: "adminUnlockCode" },
      select: { value: true },
    });
    const currentHash = typeof existing?.value === "string" ? existing.value : null;

    if (currentHash) {
      const valid = await verifyPassword(parsed.data.currentCode ?? "", currentHash);
      if (!valid) {
        return {
          status: "error",
          fieldErrors: { currentCode: ["That is not the current code."] },
        };
      }
    }

    await upsertSetting("adminUnlockCode", await hashPassword(parsed.data.newCode), "security");

    await recordAudit({
      actorId: admin.id,
      action: AUDIT_ACTIONS.SETTINGS_CHANGED,
      entityType: "settings",
      entityId: "adminUnlockCode",
      // The code itself is never recorded — only that it changed.
      metadata: { changed: "adminUnlockCode" },
    });
  } catch (error) {
    console.error("[admin] unlock code change failed:", error);
    return { status: "error", message: "That didn't save. Try again." };
  }

  revalidatePath(routes.admin.settings);
  return { status: "success", message: "Unlock code updated." };
}
