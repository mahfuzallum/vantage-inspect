"use client";

import { useState, useTransition } from "react";
import { Loader2 } from "lucide-react";
import { Modal } from "@/components/ui/modal";
import { Button, type ButtonVariant } from "@/components/ui/button";

export type ConfirmDialogProps = {
  trigger: React.ReactNode;
  title: string;
  description: string;
  confirmLabel?: string;
  variant?: ButtonVariant;
  /** Typing this exact word is required before confirm enables. */
  requireTyped?: string;
  /** Pre-bound server action — no identifier travels through the DOM. */
  action: () => Promise<unknown>;
};

/**
 * Confirmation gate for destructive admin operations.
 *
 * Never `window.confirm`: it cannot be styled, cannot explain consequences and
 * is trivially click-through. For the worst operations `requireTyped` forces
 * the administrator to type the name of what they are destroying.
 */
export function ConfirmDialog({
  trigger,
  title,
  description,
  confirmLabel = "Confirm",
  variant = "danger",
  requireTyped,
  action,
}: ConfirmDialogProps) {
  const [open, setOpen] = useState(false);
  const [typed, setTyped] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  const canConfirm = !requireTyped || typed.trim() === requireTyped;

  function handleConfirm() {
    setError(null);
    startTransition(async () => {
      try {
        await action();
        setOpen(false);
        setTyped("");
      } catch {
        setError("That didn't complete. Try again.");
      }
    });
  }

  return (
    <>
      <span onClick={() => setOpen(true)}>{trigger}</span>

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title={title}
        description={description}
        footer={
          <div className="flex justify-end gap-2">
            <Button variant="ghost" size="sm" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button
              variant={variant}
              size="sm"
              disabled={!canConfirm || isPending}
              onClick={handleConfirm}
            >
              {isPending ? <Loader2 className="size-3.5 animate-spin" aria-hidden="true" /> : null}
              {confirmLabel}
            </Button>
          </div>
        }
      >
        {requireTyped ? (
          <div className="space-y-2">
            <label htmlFor="confirm-typed" className="block text-sm text-ink-muted">
              Type <strong className="text-ink">{requireTyped}</strong> to confirm.
            </label>
            <input
              id="confirm-typed"
              value={typed}
              autoComplete="off"
              onChange={(event) => setTyped(event.target.value)}
              className="h-9 w-full rounded-control border border-line bg-raised px-3 text-sm text-ink focus:border-accent focus:outline-none"
            />
          </div>
        ) : null}

        {error ? (
          <p role="alert" className="mt-3 text-sm text-critical">
            {error}
          </p>
        ) : null}
      </Modal>
    </>
  );
}
