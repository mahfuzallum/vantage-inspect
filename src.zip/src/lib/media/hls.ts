/**
 * Resolves the playback URL for a recording.
 *
 * Public delivery points at STORAGE_PUBLIC_URL — a CDN origin — so segments
 * are served by the edge rather than travelling through the Next.js server.
 * Routing thousands of six-second segments through the application would be
 * both slow and pointless.
 *
 * With no CDN configured the local public base is used instead. On the local
 * provider the pipeline writes into `public/`, which Next.js already serves as
 * static files, so a development install plays without a bucket. Returning
 * null here instead would leave every transcoded recording unplayable for the
 * one setup that has no CDN to point at.
 */
export function publicMediaUrl(objectKey: string | null | undefined): string | null {
  if (!objectKey) return null;
  const configured = process.env.STORAGE_PUBLIC_URL || process.env.MEDIA_PUBLIC_BASE_URL;
  const base = (configured || "/uploads").replace(/\/$/, "");
  return `${base}/${objectKey}`;
}

/** True when the browser can play HLS without a JavaScript library. */
export function hasNativeHlsSupport(video: HTMLVideoElement): boolean {
  return (
    video.canPlayType("application/vnd.apple.mpegurl") !== "" ||
    video.canPlayType("application/x-mpegURL") !== ""
  );
}

export const HLS_MIME = "application/vnd.apple.mpegurl";
