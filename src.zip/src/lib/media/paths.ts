/**
 * Object key layout for the media pipeline.
 *
 * Keys are derived from ids the application controls, never from an uploaded
 * filename — that removes path traversal as a category of bug rather than
 * trying to sanitise it away. Originals live under a separate prefix from
 * derived assets so a bucket policy can make `original/` private while
 * `hls/`, `thumbnails/` and `previews/` are served publicly through a CDN.
 */

/** Guards against a malformed id ever reaching a key. */
function safeSegment(value: string): string {
  const cleaned = value.replace(/[^a-zA-Z0-9_-]/g, "");
  if (!cleaned || cleaned.length > 64) {
    throw new Error("Refusing to build a storage key from an unsafe identifier");
  }
  return cleaned;
}

export const storagePaths = {
  /** Private: the untouched upload. Never exposed through a public URL. */
  source: (videoId: string, extension: string) =>
    `videos/original/${safeSegment(videoId)}/source${normalizeExtension(extension)}`,

  hlsMaster: (videoId: string) => `videos/hls/${safeSegment(videoId)}/master.m3u8`,

  hlsVariantDir: (videoId: string, label: string) =>
    `videos/hls/${safeSegment(videoId)}/${safeSegment(label)}`,

  hlsVariantPlaylist: (videoId: string, label: string) =>
    `videos/hls/${safeSegment(videoId)}/${safeSegment(label)}/playlist.m3u8`,

  thumbnail: (videoId: string, extension = "webp") =>
    `videos/thumbnails/${safeSegment(videoId)}/thumbnail.${safeSegment(extension)}`,

  preview: (videoId: string) => `videos/previews/${safeSegment(videoId)}/preview.webp`,

  /**
   * Per-entity asset keys. The filename component is generated, never taken
   * from the upload — a caller cannot influence where bytes land.
   */
  contentThumbnail: (contentId: string, token: string, extension: string) =>
    `content/${safeSegment(contentId)}/thumbnail/${safeSegment(token)}${normalizeExtension(extension)}`,

  contentVideo: (contentId: string, token: string, extension: string) =>
    `content/${safeSegment(contentId)}/video/${safeSegment(token)}${normalizeExtension(extension)}`,

  creatorAvatar: (creatorId: string, token: string, extension: string) =>
    `creator/${safeSegment(creatorId)}/avatar/${safeSegment(token)}${normalizeExtension(extension)}`,

  creatorBanner: (creatorId: string, token: string, extension: string) =>
    `creator/${safeSegment(creatorId)}/banner/${safeSegment(token)}${normalizeExtension(extension)}`,

  /** Site-level assets: logo, favicon, default social image. */
  site: (kind: string, token: string, extension: string) =>
    `site/${safeSegment(kind)}/${safeSegment(token)}${normalizeExtension(extension)}`,

  /** Everything belonging to one recording, for deletion. */
  prefixes: (videoId: string) => {
    const id = safeSegment(videoId);
    return [
      `videos/original/${id}/`,
      `videos/hls/${id}/`,
      `videos/thumbnails/${id}/`,
      `videos/previews/${id}/`,
    ];
  },
} as const;

/**
 * Lowercased, dot-prefixed, strictly alphanumeric file extension.
 *
 * Takes the final segment and strips every non-alphanumeric character,
 * including interior dots. Keeping dots would let a crafted value such as
 * "../../sh" or "php.png" survive into a storage key as a double extension —
 * harmless on its own, but exactly the shape that trips up a misconfigured
 * web server later.
 */
export function normalizeExtension(raw: string): string {
  const lastSegment =
    raw
      .toLowerCase()
      .split(/[./\\]/)
      .filter(Boolean)
      .pop() ?? "";
  const cleaned = lastSegment.replace(/[^a-z0-9]/g, "").slice(0, 12);
  return cleaned ? `.${cleaned}` : "";
}

/** True when a key holds a derived asset that is safe to serve publicly. */
export function isPublicKey(key: string): boolean {
  // Original uploads stay private; everything derived or presentational is
  // safe to serve from a CDN.
  if (key.startsWith("videos/original/")) return false;
  if (key.startsWith("content/") && key.includes("/video/")) return false;

  return (
    key.startsWith("videos/hls/") ||
    key.startsWith("videos/thumbnails/") ||
    key.startsWith("videos/previews/") ||
    key.startsWith("content/") ||
    key.startsWith("creator/") ||
    key.startsWith("site/")
  );
}
