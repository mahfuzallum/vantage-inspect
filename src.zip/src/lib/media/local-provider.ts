import "server-only";
import { copyFile, mkdir, stat, unlink, writeFile } from "node:fs/promises";
import path from "node:path";
import { randomToken } from "@/lib/utils/hash";
import { serverEnv } from "@/lib/env";
import type { MediaStorageProvider, ObjectMetadata, StoredObject, UploadInput } from "./types";

/**
 * Filesystem storage for local development and single-server deployments.
 * Keys are random, so an uploaded filename can never traverse the tree.
 */
export class LocalMediaProvider implements MediaStorageProvider {
  readonly id = "LOCAL" as const;

  async upload(input: UploadInput): Promise<StoredObject> {
    const env = serverEnv();
    const extension = path
      .extname(input.filename)
      .toLowerCase()
      .replace(/[^.a-z0-9]/g, "");
    const objectKey = path.posix.join(input.prefix ?? "misc", `${randomToken(12)}${extension}`);
    const absolute = path.join(env.MEDIA_LOCAL_ROOT, objectKey);

    await mkdir(path.dirname(absolute), { recursive: true });
    await writeFile(absolute, input.body);

    return {
      provider: "LOCAL",
      bucket: null,
      objectKey,
      url: null,
      mimeType: input.mimeType,
      sizeBytes: input.body.byteLength,
    };
  }

  /**
   * Writes a buffer to an exact key.
   *
   * The worker addresses its output by key — `videos/hls/<id>/master.m3u8` and
   * so on — rather than letting the provider invent one, because the playlist
   * it just generated references those paths literally. `upload()` above
   * randomises the name and is wrong for anything the pipeline produces.
   */
  async putBuffer(objectKey: string, body: Buffer, contentType: string): Promise<StoredObject> {
    const absolute = path.join(serverEnv().MEDIA_LOCAL_ROOT, objectKey);
    await mkdir(path.dirname(absolute), { recursive: true });
    await writeFile(absolute, body);

    return {
      provider: "LOCAL",
      bucket: null,
      objectKey,
      url: null,
      mimeType: contentType,
      sizeBytes: body.byteLength,
    };
  }

  /** Same, for output FFmpeg already wrote to the scratch directory. */
  async putFile(objectKey: string, filePath: string, contentType: string): Promise<StoredObject> {
    const absolute = path.join(serverEnv().MEDIA_LOCAL_ROOT, objectKey);
    await mkdir(path.dirname(absolute), { recursive: true });
    await copyFile(filePath, absolute);
    const info = await stat(absolute);

    return {
      provider: "LOCAL",
      bucket: null,
      objectKey,
      url: null,
      mimeType: contentType,
      sizeBytes: info.size,
    };
  }

  async delete(object: StoredObject): Promise<void> {
    if (!object.objectKey) return;
    const absolute = path.join(serverEnv().MEDIA_LOCAL_ROOT, object.objectKey);
    await unlink(absolute).catch(() => undefined);
  }

  async resolveUrl(object: StoredObject): Promise<string> {
    if (!object.objectKey) return "";
    const base = serverEnv().MEDIA_PUBLIC_BASE_URL.replace(/\/$/, "");
    return `${base}/${object.objectKey}`;
  }

  private absolutePath(object: StoredObject): string | null {
    if (!object.objectKey) return null;
    return path.join(serverEnv().MEDIA_LOCAL_ROOT, object.objectKey);
  }

  async exists(object: StoredObject): Promise<boolean> {
    const absolute = this.absolutePath(object);
    if (!absolute) return false;
    return stat(absolute)
      .then(() => true)
      .catch(() => false);
  }

  async getMetadata(object: StoredObject): Promise<ObjectMetadata | null> {
    const absolute = this.absolutePath(object);
    if (!absolute || !object.objectKey) return null;

    try {
      const info = await stat(absolute);
      return {
        objectKey: object.objectKey,
        sizeBytes: info.size,
        mimeType: object.mimeType,
        lastModified: info.mtime,
        etag: null,
      };
    } catch {
      return null;
    }
  }

  /**
   * Local disk cannot issue a signed upload, so there is nothing to hand the
   * browser. Returning null is the honest answer — callers fall back to
   * posting the file through the application, which is acceptable in
   * development and is exactly why this is optional on the interface.
   */
  async createUploadAuthorization(): Promise<null> {
    return null;
  }
}
