import "server-only";

import type { MediaAsset } from "@prisma/client";
import { serverEnv } from "@/lib/env";
import { safeExternalUrl } from "@/lib/security/sanitize";
import { LocalMediaProvider } from "./local-provider";
import { S3MediaProvider } from "./s3-provider";
import type {
  MediaStorageProvider,
  SignedUrlOptions,
  StoredObject,
} from "./types";

export * from "./types";

let provider: MediaStorageProvider | null = null;

export function mediaProvider(): MediaStorageProvider {
  if (!provider) {
    provider =
      serverEnv().MEDIA_PROVIDER === "s3"
        ? new S3MediaProvider()
        : new LocalMediaProvider();
  }

  return provider;
}

function toStoredObject(asset: MediaAsset): StoredObject {
  return {
    provider: asset.provider,
    bucket: asset.bucket,
    objectKey: asset.objectKey,
    url: asset.url,
    mimeType: asset.mimeType,
    sizeBytes: asset.sizeBytes,
  };
}

export async function resolveAssetUrl(
  asset: MediaAsset | null | undefined,
  options?: SignedUrlOptions,
): Promise<string | null> {
  if (!asset) return null;

  if (asset.provider === "EXTERNAL") {
    return safeExternalUrl(asset.url);
  }

  return (
    (await mediaProvider().resolveUrl(
      toStoredObject(asset),
      options,
    )) || null
  );
}

export async function deleteAsset(
  asset: MediaAsset,
): Promise<void> {
  if (asset.provider === "EXTERNAL") return;

  await mediaProvider().delete(
    toStoredObject(asset),
  );
}